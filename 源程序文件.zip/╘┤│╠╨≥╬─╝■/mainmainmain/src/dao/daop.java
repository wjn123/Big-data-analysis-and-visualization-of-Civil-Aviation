package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DBUtil.DBUtil;
import javabean.t_corp;
import javabean.t_corp_stock;
import javabean.t_corp_stock_1;
import javabean.t_m_corp_corp_stock;

public class daop {
	public static t_corp get_tcorp(String name) {
		String sql = "select * from t_corp where CORP_NAME ='" + name + "'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		t_corp s = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String REG_CAPI = rs.getString("REG_CAPI");
				String START_DATE = rs.getString("START_DATE");
				String CORP_STATUS = rs.getString("CORP_STATUS");
				String REG_NO = rs.getString("REG_NO");
				String TAXPAY_NUM = rs.getString("TAXPAY_NUM");
				String UNI_SCID = rs.getString("UNI_SCID");
				String ORG_INST_CODE = rs.getString("ORG_INST_CODE");
				String ECON_KIND = rs.getString("ECON_KIND");
				String STAFF_SIZE = rs.getString("STAFF_SIZE");
				String FARE_TERM_START = rs.getString("FARE_TERM_START");
				String BELONG_ORG = rs.getString("BELONG_ORG");
				String CHECK_DATE = rs.getString("CHECK_DATE");
				String ENGLISH_NAME = rs.getString("ENGLISH_NAME");
				String FORMER_NAME = rs.getString("FORMER_NAME");
				String BELONG_DIST_ORG = rs.getString("BELONG_DIST_ORG");
				String BELONG_TRADE = rs.getString("BELONG_TRADE");
				String ADDR = rs.getString("ADDR");
				String FARE_SCOPE = rs.getString("FARE_SCOPE");
				s=new t_corp(REG_CAPI,START_DATE,CORP_STATUS,REG_NO,TAXPAY_NUM,UNI_SCID,ORG_INST_CODE,ECON_KIND,STAFF_SIZE,FARE_TERM_START,
						BELONG_ORG,CHECK_DATE,ENGLISH_NAME,FORMER_NAME,BELONG_DIST_ORG,BELONG_TRADE,ADDR,FARE_SCOPE);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return s;
	}
	
	
	//ͨ����˾���Ƶõ�id��seq_id
	public static t_m_corp_corp_stock get_tcorp_idandseqid(String name) {
		String sql = "select * from t_corp where CORP_NAME ='" + name + "'";
		Connection conn = DBUtil.getConn();
		Statement state = null;
		ResultSet rs = null;
		t_m_corp_corp_stock s = null;
		try {
			state = conn.createStatement();
			rs = state.executeQuery(sql);
			while (rs.next()) {
				String SEQ_ID = rs.getString("SEQ_ID");
				String ID = rs.getString("ID");
				s=new t_m_corp_corp_stock(ID,SEQ_ID);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs, state, conn);
		}
		return s;
	}
	
	//ͨ����˾id��sql_id�õ��ɶ�id��seq_id
		public static List<t_m_corp_corp_stock> get_tcorp_stock_idandseqid(t_m_corp_corp_stock t) {
			List<t_m_corp_corp_stock> list = new ArrayList<>();
			String sql = "select * from t_m_corp_corp_stock where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			ResultSet rs = null;
			try {
				state = conn.createStatement();
				rs = state.executeQuery(sql);
				t_m_corp_corp_stock s = null;
				while (rs.next()) {
					String SEQ_ID = rs.getString("SUB_SEQ_ID");
					String ID = rs.getString("SUB_ID");
					s=new t_m_corp_corp_stock(ID,SEQ_ID);
					list.add(s);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(rs, state, conn);
			}
			return list;
		}
		
		
		public static t_corp_stock get_tstock_mess(t_m_corp_corp_stock t) {
			String sql = "select * from t_corp_stock where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
			Connection conn = DBUtil.getConn();
			Statement state = null;
			ResultSet rs = null;
			t_corp_stock s = null;
			try {
				state = conn.createStatement();
				rs = state.executeQuery(sql);
				while (rs.next()) {
					String STOCK_TYPE = rs.getString("STOCK_TYPE");
					String STOCK_PERCENT = rs.getString("STOCK_PERCENT");
					String STOCK_CAPI = rs.getString("STOCK_CAPI");
					String STOCK_NAME = rs.getString("STOCK_NAME");
					
					s=new t_corp_stock(STOCK_TYPE,STOCK_PERCENT,STOCK_CAPI,STOCK_NAME);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBUtil.close(rs, state, conn);
			}
			return s;
		}
		
		
				public static List<t_corp_stock_1> get_tstock_mess(String name) {
					List<t_corp_stock_1> list = new ArrayList<>();
					String sql = "select * from t_corp_stock where STOCK_NAME ='" + name + "'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						t_corp_stock_1 s = null;
						while (rs.next()) {
							String ID = rs.getString("ID");
							String SEQ_ID = rs.getString("SEQ_ID");
							String STOCK_CAPI = rs.getString("STOCK_CAPI");
							s=new t_corp_stock_1(ID,SEQ_ID,STOCK_CAPI);
							list.add(s);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return list;
				}
				
				
				public static t_m_corp_corp_stock get_tcorp_idandseqid(t_corp_stock_1 t) {
					String sql = "select * from t_m_corp_corp_stock where SUB_ID ='" + t.id + "' and SUB_SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					t_m_corp_corp_stock s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							String SEQ_ID = rs.getString("SEQ_ID");
							String ID = rs.getString("ID");
							s=new t_m_corp_corp_stock(ID,SEQ_ID);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return s;
				}
				
				public static String get_tcorp_name(t_m_corp_corp_stock t) {
					String sql = "select * from t_corp where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					String s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							s = rs.getString("CORP_NAME");
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return s;
				}
				
				
				
				public static List<t_m_corp_corp_stock> get_pertains_idandseq_id(t_m_corp_corp_stock t) {
					List<t_m_corp_corp_stock> list = new ArrayList<>();
					String sql = "select * from t_m_corp_corp_pertains where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						t_m_corp_corp_stock s = null;
						while (rs.next()) {
							String ID = rs.getString("SUB_ID");
							String SEQ_ID = rs.getString("SUB_SEQ_ID");
							s=new t_m_corp_corp_stock(ID,SEQ_ID);
							list.add(s);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return list;
				}
				
				
				public static String get_pertains_name(t_m_corp_corp_stock t) {
					String sql = "select * from t_corp_pertains where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					String s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							s = rs.getString("PERSON_NAME");
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
				return s;
				}
				
				
				public static List<t_m_corp_corp_stock> get_dist_idandseq_id(t_m_corp_corp_stock t) {
					List<t_m_corp_corp_stock> list = new ArrayList<>();
					String sql = "select * from t_m_corp_corp_dist where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						t_m_corp_corp_stock s = null;
						while (rs.next()) {
							String ID = rs.getString("SUB_ID");
							String SEQ_ID = rs.getString("SUB_SEQ_ID");
							s=new t_m_corp_corp_stock(ID,SEQ_ID);
							list.add(s);
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return list;
				}
				
				public static String get_dist_name(t_m_corp_corp_stock t) {
					String sql = "select * from t_corp_dist where ID ='" + t.id + "' and SEQ_ID = '" + t.seq_id +"'";
					Connection conn = DBUtil.getConn();
					Statement state = null;
					ResultSet rs = null;
					String s = null;
					try {
						state = conn.createStatement();
						rs = state.executeQuery(sql);
						while (rs.next()) {
							s = rs.getString("DIST_NAME");
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						DBUtil.close(rs, state, conn);
					}
					return s;
				}
				
}
