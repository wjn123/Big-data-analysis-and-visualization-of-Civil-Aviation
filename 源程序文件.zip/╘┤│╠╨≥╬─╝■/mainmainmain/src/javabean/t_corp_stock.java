package javabean;

public class t_corp_stock {

	public String STOCK_TYPE;
	public String STOCK_PERCENT;
	public String STOCK_CAPI;
	public String STOCK_NAME;
	public String getSTOCK_TYPE() {
		return STOCK_TYPE;
	}
	public void setSTOCK_TYPE(String sTOCK_TYPE) {
		STOCK_TYPE = sTOCK_TYPE;
	}
	public String getSTOCK_PERCENT() {
		return STOCK_PERCENT;
	}
	public void setSTOCK_PERCENT(String sTOCK_PERCENT) {
		STOCK_PERCENT = sTOCK_PERCENT;
	}
	public String getSTOCK_CAPI() {
		return STOCK_CAPI;
	}
	public void setSTOCK_CAPI(String sTOCK_CAPI) {
		STOCK_CAPI = sTOCK_CAPI;
	}
	public String getSTOCK_NAME() {
		return STOCK_NAME;
	}
	public void setSTOCK_NAME(String sTOCK_NAME) {
		STOCK_NAME = sTOCK_NAME;
	}
	
	public t_corp_stock(String STOCK_TYPE,
	String STOCK_PERCENT,
	String STOCK_CAPI,
	String STOCK_NAME){
		this.STOCK_CAPI = STOCK_CAPI;
		this.STOCK_NAME = STOCK_NAME;
		this.STOCK_PERCENT = STOCK_PERCENT;
		this.STOCK_TYPE = STOCK_TYPE;
	}
	
}
