package javabean;
public class t_corp {
	public String REG_CAPI;
	public String START_DATE;
	public String CORP_STATUS;
	public String REG_NO;
	public String TAXPAY_NUM;
	public String UNI_SCID;
	public String ORG_INST_CODE;
	public String ECON_KIND;
	public String STAFF_SIZE;
	public String FARE_TERM_START;
	public String BELONG_ORG;
	public String CHECK_DATE;
	public String ENGLISH_NAME;
	public String FORMER_NAME;
	public String BELONG_DIST_ORG;
	public String BELONG_TRADE;
	public String ADDR;
	public String FARE_SCOPE;
	public String getREG_CAPI() {
		return REG_CAPI;
	}
	public void setREG_CAPI(String rEG_CAPI) {
		REG_CAPI = rEG_CAPI;
	}
	public String getSTART_DATE() {
		return START_DATE;
	}
	public void setSTART_DATE(String sTART_DATE) {
		START_DATE = sTART_DATE;
	}
	public String getCORP_STATUS() {
		return CORP_STATUS;
	}
	public void setCORP_STATUS(String cORP_STATUS) {
		CORP_STATUS = cORP_STATUS;
	}
	public String getREG_NO() {
		return REG_NO;
	}
	public void setREG_NO(String rEG_NO) {
		REG_NO = rEG_NO;
	}
	public String getTAXPAY_NUM() {
		return TAXPAY_NUM;
	}
	public void setTAXPAY_NUM(String tAXPAY_NUM) {
		TAXPAY_NUM = tAXPAY_NUM;
	}
	public String getUNI_SCID() {
		return UNI_SCID;
	}
	public void setUNI_SCID(String uNI_SCID) {
		UNI_SCID = uNI_SCID;
	}
	public String getORG_INST_CODE() {
		return ORG_INST_CODE;
	}
	public void setORG_INST_CODE(String oRG_INST_CODE) {
		ORG_INST_CODE = oRG_INST_CODE;
	}
	public String getECON_KIND() {
		return ECON_KIND;
	}
	public void setECON_KIND(String eCON_KIND) {
		ECON_KIND = eCON_KIND;
	}
	public String getSTAFF_SIZE() {
		return STAFF_SIZE;
	}
	public void setSTAFF_SIZE(String sTAFF_SIZE) {
		STAFF_SIZE = sTAFF_SIZE;
	}
	public String getFARE_TERM_START() {
		return FARE_TERM_START;
	}
	public void setFARE_TERM_START(String fARE_TERM_START) {
		FARE_TERM_START = fARE_TERM_START;
	}
	public String getBELONG_ORG() {
		return BELONG_ORG;
	}
	public void setBELONG_ORG(String bELONG_ORG) {
		BELONG_ORG = bELONG_ORG;
	}
	public String getCHECK_DATE() {
		return CHECK_DATE;
	}
	public void setCHECK_DATE(String cHECK_DATE) {
		CHECK_DATE = cHECK_DATE;
	}
	public String getENGLISH_NAME() {
		return ENGLISH_NAME;
	}
	public void setENGLISH_NAME(String eNGLISH_NAME) {
		ENGLISH_NAME = eNGLISH_NAME;
	}
	public String getFORMER_NAME() {
		return FORMER_NAME;
	}
	public void setFORMER_NAME(String fORMER_NAME) {
		FORMER_NAME = fORMER_NAME;
	}
	public String getBELONG_DIST_ORG() {
		return BELONG_DIST_ORG;
	}
	public void setBELONG_DIST_ORG(String bELONG_DIST_ORG) {
		BELONG_DIST_ORG = bELONG_DIST_ORG;
	}
	public String getBELONG_TRADE() {
		return BELONG_TRADE;
	}
	public void setBELONG_TRADE(String bELONG_TRADE) {
		BELONG_TRADE = bELONG_TRADE;
	}
	public String getADDR() {
		return ADDR;
	}
	public void setADDR(String aDDR) {
		ADDR = aDDR;
	}
	public String getFARE_SCOPE() {
		return FARE_SCOPE;
	}
	public void setFARE_SCOPE(String fARE_SCOPE) {
		FARE_SCOPE = fARE_SCOPE;
	}
	public t_corp(String REG_CAPI,
	String START_DATE,
	String CORP_STATUS,
	String REG_NO,
	String TAXPAY_NUM,
	String UNI_SCID,
	String ORG_INST_CODE,
	String ECON_KIND,
	String STAFF_SIZE,
	String FARE_TERM_START,
	String BELONG_ORG,
	String CHECK_DATE,
	String ENGLISH_NAME,
	String FORMER_NAME,
	String BELONG_DIST_ORG,
	String BELONG_TRADE,
	String ADDR,
	String FARE_SCOPE){
		this.REG_CAPI = REG_CAPI;
		this.START_DATE = START_DATE;
		this.CORP_STATUS = CORP_STATUS;
		this.REG_NO = REG_NO;
		this.TAXPAY_NUM = TAXPAY_NUM;
		this.UNI_SCID = UNI_SCID;
		this.ORG_INST_CODE = ORG_INST_CODE;
		this.ECON_KIND = ECON_KIND;
		this.STAFF_SIZE = STAFF_SIZE;
		this.FARE_TERM_START = FARE_TERM_START;
		this.BELONG_ORG = BELONG_ORG;
		this.CHECK_DATE = CHECK_DATE;
		this.ENGLISH_NAME = ENGLISH_NAME;
		this.FORMER_NAME = FORMER_NAME;
		this.BELONG_DIST_ORG = BELONG_DIST_ORG;
		this.BELONG_TRADE = BELONG_TRADE;
		this.ADDR = ADDR;
		this.FARE_SCOPE = FARE_SCOPE;
		
	}
}
