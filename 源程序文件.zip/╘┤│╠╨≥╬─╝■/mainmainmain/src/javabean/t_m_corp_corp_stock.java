package javabean;

public class t_m_corp_corp_stock {

	public String id;
	public String seq_id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeq_id() {
		return seq_id;
	}
	public void setSeq_id(String seq_id) {
		this.seq_id = seq_id;
	}
	public t_m_corp_corp_stock(String id,String seq_id){
		this.id = id;
		this.seq_id = seq_id;
		
	}
}
