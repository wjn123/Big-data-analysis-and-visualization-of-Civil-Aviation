package javabean;

public class t_corp_stock_1 {
	
	public String id;
	public String seq_id;
	public String capi;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSeq_id() {
		return seq_id;
	}
	public void setSeq_id(String seq_id) {
		this.seq_id = seq_id;
	}
	public String getCapi() {
		return capi;
	}
	public void setCapi(String capi) {
		this.capi = capi;
	}
	
	public t_corp_stock_1(String id,String seq_id,String capi){
		this.id  = id;
		this.seq_id = seq_id;
		this.capi = capi;
	}
	
}
