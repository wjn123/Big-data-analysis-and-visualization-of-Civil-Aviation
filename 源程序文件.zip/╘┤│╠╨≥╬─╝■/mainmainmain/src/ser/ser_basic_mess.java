package ser;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop;
import javabean.t_corp;
@WebServlet("/ser_basic_mess")
public class ser_basic_mess extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		req.setCharacterEncoding("utf-8");
		String name = req.getParameter("name");
		t_corp corp = null;
		
		if(name==null){
			Cookie[] cookies=req.getCookies();
			String name1 = "";
	        if(cookies!=null&&cookies.length>0){
	            for(Cookie c:cookies){
	                if(c.getName().equals("name")){
	                	name1=URLDecoder.decode(c.getValue(), "utf-8");
	                }
	            }
	        }
	        corp = daop.get_tcorp(name1);	
	        
	        req.setAttribute("corp", corp);
			req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
		}else{
		corp = daop.get_tcorp(name);
		if(corp==null){
			req.setAttribute("message", "δ��ѯ������ҵ�����Ϣ");
			req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
		}else{
			String na = URLEncoder.encode(name,"UTF-8");
			Cookie cookiename=new Cookie("name",na);
            cookiename.setMaxAge(864000);
            resp.addCookie(cookiename);
            
			req.setAttribute("corp", corp);
			req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
		}
		}
	}
}

