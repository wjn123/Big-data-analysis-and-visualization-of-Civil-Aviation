package ser;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop;
import javabean.t_corp_stock;
import javabean.t_corp_stock_1;
import javabean.t_m_corp_corp_stock;
@WebServlet("/ser_invest")
public class ser_invest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Cookie[] cookies=req.getCookies();
		String name = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("name")){
                	name=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
        
        if(name.equals("")){
        	req.setAttribute("message", "�������빫˾���ƽ��в�ѯ");
        	req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
        }else{
        	
        	t_m_corp_corp_stock t = daop.get_tcorp_idandseqid(name);
        	
        	List<t_m_corp_corp_stock> list = daop.get_tcorp_stock_idandseqid(t);

    		String [] cspi = null;
    		String [] nam = null;
        	if(list.size()!=0){
        		t_corp_stock [] all_mess = new t_corp_stock[list.size()];
        		cspi = new String[list.size()];
        		nam = new String[list.size()];
        		for(int i=0;i<list.size();i++){
        			all_mess[i] = daop.get_tstock_mess((t_m_corp_corp_stock)list.get(i));
        			cspi[i] = all_mess[i].STOCK_CAPI;
        			nam[i] = all_mess[i].STOCK_NAME;
        		}
        	}
        	
        	
        	
        	
        	List<t_corp_stock_1> list1 = daop.get_tstock_mess(name);
        	String [] corp_name = null;
        	String [] corp_out_cspi = null;
        	
        	if(list1.size()!=0){
        		t_m_corp_corp_stock [] corp = new t_m_corp_corp_stock[list1.size()];
        		corp_name = new String[list1.size()];
        		corp_out_cspi = new String[list1.size()];
        		for(int i=0;i<list1.size();i++){
            		corp[i] = daop.get_tcorp_idandseqid(list1.get(i));
            		corp_name[i] = daop.get_tcorp_name(corp[i]);
            		
            		corp_out_cspi[i] = list1.get(i).capi;
        		}
        	}
        	
        	if(list.size()==0&&list1.size()==0){
        		req.setAttribute("message", "�ù�˾û�йɶ��Ͷ���Ͷ��");
            	req.getRequestDispatcher("invest.jsp").forward(req,resp);
        	}else{
        		req.setAttribute("cspi", cspi);//�ɶ�Ͷ�ʵ�Ǯ��
        		req.setAttribute("name", nam);//�ɶ�����
        		
        		req.setAttribute("corp_name", corp_name);
        		req.setAttribute("corp_out_cspi", corp_out_cspi);

        		req.setAttribute("main_corp_name", name);
            	req.getRequestDispatcher("invest.jsp").forward(req,resp);
        	}
        }
		
	}

}
