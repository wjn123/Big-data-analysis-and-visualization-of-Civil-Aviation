package ser;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daop;
import javabean.t_corp_stock;
import javabean.t_m_corp_corp_stock;

@WebServlet("/ser_ownership")
public class ser_ownership extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Cookie[] cookies=req.getCookies();
		String name = "";
        if(cookies!=null&&cookies.length>0){
            for(Cookie c:cookies){
                if(c.getName().equals("name")){
                	name=URLDecoder.decode(c.getValue(), "utf-8");
                }
            }
        }
        
        if(name.equals("")){
        	req.setAttribute("message", "�������빫˾���ƽ��в�ѯ");
        	req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
        }else{
        	
        	t_m_corp_corp_stock t = daop.get_tcorp_idandseqid(name);
        	
        	List<t_m_corp_corp_stock> list = daop.get_tcorp_stock_idandseqid(t);
        	
        	if(list.size()==0){
        		req.setAttribute("message", "�ù�˾û�йɶ�");
            	req.getRequestDispatcher("basic_mess.jsp").forward(req,resp);
        	}else{
        		t_corp_stock [] all_mess = new t_corp_stock[list.size()];
        		String [] cspi = new String[list.size()];
        		String [] nam = new String[list.size()];
        		int [] cspi_int = new int[list.size()];
        		for(int i=0;i<list.size();i++){
        			all_mess[i] = daop.get_tstock_mess((t_m_corp_corp_stock)list.get(i));
        			cspi[i] = all_mess[i].STOCK_CAPI;
        			nam[i] = all_mess[i].STOCK_NAME;
        			cspi_int[i] = Integer.parseInt(cspi[i]);
        		}
        		
        		int max_num = 0;
        		int max_num_jb = 0;
        		for(int i=0;i<list.size();i++){
        			if(cspi_int[i]>=max_num){
        				max_num = cspi_int[i];
        				max_num_jb = i;
        			}
        		}
        		nam[max_num_jb] = nam[max_num_jb]+"(����ʵ�ʿ�����)";
        		req.setAttribute("cspi", cspi);
        		req.setAttribute("name", nam);
            	req.getRequestDispatcher("ownership.jsp").forward(req,resp);
        	}
        }
		
	}

}
